package com.example.t3_0320220094_muhamadmukhasim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T30320220094MuhamadMukhasimApplicationTests {

    @Test
    void contextLoads() {
    }

}
