package com.example.t1_0320220094_muhamadmukhasim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T10320220094MuhamadMukhasimApplicationTests {

    @Test
    void contextLoads() {
    }

}
