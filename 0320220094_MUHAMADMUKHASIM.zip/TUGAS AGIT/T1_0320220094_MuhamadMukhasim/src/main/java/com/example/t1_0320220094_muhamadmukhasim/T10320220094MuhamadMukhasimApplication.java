package com.example.t1_0320220094_muhamadmukhasim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T10320220094MuhamadMukhasimApplication {

    public static void main(String[] args) {
        SpringApplication.run(T10320220094MuhamadMukhasimApplication.class, args);
    }

}
