package com.example.t2_0320220094_muhamadmukhasim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T20320220094MuhamadMukhasimApplicationTests {

    @Test
    void contextLoads() {
    }

}
