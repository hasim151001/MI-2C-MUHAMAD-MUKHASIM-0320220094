package com.example.t2_0320220094_muhamadmukhasim;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RabbitMQController {

    private static final String queue = "MukhasimQeueu";

    @RabbitListener(queues = queue)
    public void processMessage(String message) {
        System.out.println("Pesan dari RabbitMQ: " + message);
    }

}
